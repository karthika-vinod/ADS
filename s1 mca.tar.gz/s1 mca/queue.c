#include <stdio.h>

#define MAX_SIZE 100

// Function to check if the queue is empty
int is_empty(int front, int rear) {
    return front == -1 && rear == -1;
}

// Function to check if the queue is full
int is_full(int rear) {
    return rear == MAX_SIZE - 1;
}

// Function to enqueue an element into the queue
void enqueue(int queue[], int *front, int *rear, int data) {
    if (is_full(*rear)) {
        printf("Queue is full. Cannot enqueue.\n");
        return;
    } else if (is_empty(*front, *rear)) {
        *front = *rear = 0;
    } else {
        (*rear)++;
    }
    queue[*rear] = data;
    printf("%d enqueued to the queue.\n", data);
}

// Function to dequeue an element from the queue
int dequeue(int queue[], int *front, int *rear) {
    if (is_empty(*front, *rear)) {
        printf("Queue is empty. Cannot dequeue.\n");
        return -1; // Return an invalid value to indicate an error
    } else if (*front == *rear) {
        int data = queue[*front];
        *front = *rear = -1;
        return data;
    } else {
        return queue[(*front)++];
    }
}


void display(int queue[], int front, int rear) {
    if (is_empty(front, rear)) {
        printf("Queue is empty.\n");
        return;
    }
    printf("Queue elements: ");
    for (int i = front; i <= rear; i++) {
        printf("%d ", queue[i]);
    }
    printf("\n");
}

int main() {
    int queue[MAX_SIZE];
    int front = -1, rear = -1;
    int choice, data;

    while (1) {
        printf("\nQueue Operations:\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data to enqueue: ");
                scanf("%d", &data);
                enqueue(queue, &front, &rear, data);
                break;

            case 2:
                data = dequeue(queue, &front, &rear);
                if (data != -1) {
                    printf("%d dequeued from the queue.\n", data);
                }
                break;

            case 3:
                display(queue, front, rear);
                break;

            case 4:
                printf("Exiting program.\n");
                return 0;

            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}


#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
};
struct Node* head = NULL;
struct Node* tail = NULL;
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

int countNodes() {
    int count = 0;
    struct Node* current = head;
    while (current != NULL) {
        count++;
        current = current->next;
    }
    return count;
}

void insertFirst(int data) {
    struct Node* newNode = createNode(data);
    if (head == NULL) {
        head = newNode;
        tail = newNode;
    } else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    printf("Node with data %d inserted at the first position.\n", data);
}

void insertAtPosition(int data, int position) {
    if (position < 1 || position > countNodes() + 1) {
        printf("Invalid position.\n");
        return;
    }
    if (position == 1) {
        insertFirst(data);
        return;
    }
    if (position == countNodes() + 1) {
        struct Node* newNode = createNode(data);
        newNode->prev = tail;
        tail->next = newNode;
        tail = newNode;
        printf("Node with data %d inserted at position %d.\n", data, position);
        return;
    }

    int count = 1;
    struct Node* current = head;
    while (count < position - 1) {
        current = current->next;
        count++;
    }

    struct Node* newNode = createNode(data);
    newNode->prev = current;
    newNode->next = current->next;
    current->next = newNode;
    newNode->next->prev = newNode;
    printf("Node with data %d inserted at position %d.\n", data, position);
}

void deleteFirst() {
    if (head == NULL) {
        printf("List is empty. Nothing to delete.\n");
    } else {
        struct Node* temp = head;
        head = head->next;
        if (head != NULL) {
            head->prev = NULL;
        } else {
            tail = NULL;
        }
        free(temp);
        printf("Node from the first position deleted.\n");
    }
}

void deleteLast() {
    if (tail == NULL) {
        printf("List is empty. Nothing to delete.\n");
    } else {
        struct Node* temp = tail;
        tail = tail->prev;
        if (tail != NULL) {
            tail->next = NULL;
        } else {
            head = NULL;
        }
        free(temp);
        printf("Node from the last position deleted.\n");
    }
}

void searchNode(int data) {
    struct Node* current = head;
    int position = 1;
    while (current != NULL) {
        if (current->data == data) {
            printf("Node with data %d found at position %d.\n", data, position);
            return;
        }
        current = current->next;
        position++;
    }
    printf("Node with data %d not found in the list.\n", data);
}
void traverseList() {
    struct Node* current = head;
    printf("Doubly Linked List: ");
    while (current != NULL) {
        printf("%d <-> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}

int main() {
    int choice, data, position;

    while (1) {
        printf("\nDoubly Linked List Operations:\n");
        printf("1. Create a node\n");
        printf("2. Count the number of nodes\n");
        printf("3. Insert a node at the first position\n");
        printf("4. Insert a node at a specific position\n");
        printf("5. Delete a node from the first position\n");
        printf("6. Delete a node from the last position\n");
        printf("7. Search for a node\n");
        printf("8. Traverse the list\n");
        printf("9. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data for the new node: ");
                scanf("%d", &data);
                insertAtPosition(data, countNodes() + 1);
                break;
            case 2:
                printf("Number of nodes: %d\n", countNodes());
                break;
            case 3:
                printf("Enter data for the new node: ");
                scanf("%d", &data);
                insertFirst(data);
                break;
            case 4:
                printf("Enter data for the new node: ");
                scanf("%d", &data);
                printf("Enter position to insert (1-%d): ", countNodes() + 1);
                scanf("%d", &position);
                insertAtPosition(data, position);
                break;
            case 5:
                deleteFirst();
                break;
            case 6:
                deleteLast();
                break;
            case 7:
                printf("Enter data to search: ");
                scanf("%d", &data);
                searchNode(data);
                break;
            case 8:
                traverseList();
                break;
            case 9:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}


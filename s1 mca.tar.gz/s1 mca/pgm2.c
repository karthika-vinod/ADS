#include<stdio.h>
int volume(int l,int b,int h)
{
int v;
v=h*l*b;
printf("volume is %d",v);
}
void main()
{
int x,y,z;
printf("enter the numbers:");
scanf("%d %d %d",&x,&y,&z);
volume(x,y,z);
//printf("volume is %d",v);
}
//}

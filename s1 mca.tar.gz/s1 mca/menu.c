#include <stdio.h>

int main() {
    int arr[100];
    int n, choice, position, element;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);
#include <stdio.h>

int main() {
    int arr[100];
    int n, choice, position, element;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    printf("Enter the elements of the array: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    while (1) {
        printf("\nMenu:\n");
        printf("1. Insert an element\n");
        printf("2. Delete an element\n");
        printf("3. Traverse the array\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the position to insert the element: ");
                scanf("%d", &position);
                if (position < 0 || position > n) {
                    printf("Invalid position.\n");
                } else {
                    printf("Enter the element to insert: ");
                    scanf("%d", &element);
                    for (int i = n; i > position; i--) {
                        arr[i] = arr[i - 1];
                    }
                    arr[position] = element;
                    n++;
                }
                break;

            case 2:
                printf("Enter the position to delete the element: ");
                scanf("%d", &position);
                if (position < 0 || position >= n) {
                    printf("Invalid position.\n");
                } else {
                    for (int i = position; i < n - 1; i++) {
                        arr[i] = arr[i + 1];
                    }
                    n--;
                }
                break;

            case 3:
                printf("Array elements: ");
                for (int i = 0; i < n; i++) {
                    printf("%d ", arr[i]);
                }
                printf("\n");
                break;

            case 4:
                printf("Exiting the program.\n");
                return 0;

            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
	

    printf("Enter the elements of the array: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    while (1) {
        printf("\nMenu:\n");
        printf("1. Insert an element\n");
        printf("2. Delete an element\n");
        printf("3. Traverse the array\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the position to insert the element: ");
                scanf("%d", &position);
                if (position < 0 || position > n) {
                    printf("Invalid position.\n");
                } else {
                    printf("Enter the element to insert: ");
                    scanf("%d", &element);
                    for (int i = n; i > position; i--) {
                        arr[i] = arr[i - 1];
                    }
                    arr[position] = element;
                    n++;
                }
                break;

            case 2:
                printf("Enter the position to delete the element: ");
                scanf("%d", &position);
                if (position < 0 || position >= n) {
                    printf("Invalid position.\n");
                } else {
                    for (int i = position; i < n - 1; i++) {
                        arr[i] = arr[i + 1];
                    }
                    n--;
                }
                break;

            case 3:
                printf("Array elements: ");
                for (int i = 0; i < n; i++) {
                    printf("%d ", arr[i]);
                }
                printf("\n");
                break;

            case 4:
                printf("Exiting the program.\n");
                return 0;

            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
	



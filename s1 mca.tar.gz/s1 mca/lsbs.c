#include <stdio.h>
int linearSearch(int arr[], int size, int target) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == target) {
            return i;
        }
    }
    return -1; 
}
int binarySearch(int arr[], int size, int target) {
    int left = 0;
    int right = size - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] == target) {
            return mid; 
        }

        if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    return -1; 
}

int main() {
    int arr[100];
    int size, target, result;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &size);

    if (size <= 0) {
        printf("Invalid array size. Please enter a positive size.\n");
        return 1;
    }

    printf("Enter %d integers:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the element you want to search for: ");
    scanf("%d", &target);
    result = linearSearch(arr, size, target);
    if (result != -1) {
        printf("Linear Search: Element %d found at index %d\n", target, result);
    } else {
        printf("Linear Search: Element %d not found in the array\n", target);
    }

    result = binarySearch(arr, size, target);
    if (result != -1) {
        printf("Binary Search: Element %d found at index %d\n", target, result);
    } else {
        printf("Binary Search: Element %d not found in the array\n", target);
    }

    return 0;
}


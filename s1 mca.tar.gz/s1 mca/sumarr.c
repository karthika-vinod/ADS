#include <stdio.h>
int sumArray (int arr[], int size)
{
  int sum=0;
   for(int i=0;i<size;i++){
     sum+=arr[i];
   }
   return sum;
}
int main(){
 int n;
 printf("enter the number of elements in array:");
 scanf("%d",&n);
 int arr[n];
 printf("enter %d elements :\n ",n);
  for(int i=0;i<n;i++)
  {
  scanf("%d",&arr[i]);
  }
 int total=sumArray(arr,n);
 printf("sum of the elements in the array :%d \n",total);
 return 0;
 } 
  
   
   

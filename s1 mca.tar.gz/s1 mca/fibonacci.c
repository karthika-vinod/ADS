#include<stdio.h>
int main()
{
  int a=0,b=1,c,i,n;
  printf("Enter the limit for fibonacci series: ");
  scanf("%d",&n);
  printf("\n The fibonacci series is: ");
  
  for(i=0;i<n;i++)
  {
  	printf("%d ,",a);
  	c=a+b;
  	a=b;
  	b=c;
  
  }
  return 0;
 }

#include <stdio.h>
#include <stdlib.h>


struct Node {
    int data;
    struct Node* next;
};


void push(struct Node** top, int data);
int pop(struct Node** top);
void traverse(struct Node* top);

int main() {
    struct Node* top = NULL; 

    int choice, data;

    do {
    
        printf("\nMenu:\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Traverse\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data to push: ");
                scanf("%d", &data);
                push(&top, data);
                break;
            case 2:
                if (top != NULL) {
                    printf("Popped element: %d\n", pop(&top));
                } else {
                    printf("Stack is empty\n");
                }
                break;
            case 3:
                printf("Stack elements:\n");
                traverse(top);
                break;
            case 4:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    } while (choice != 4);

    return 0;
}


void push(struct Node** top, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    newNode->data = data;
    newNode->next = *top;
    *top = newNode;

    printf("%d pushed onto the stack.\n", data);
}


int pop(struct Node** top) {
    if (*top == NULL) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }

    struct Node* temp = *top;
    int data = temp->data;
    *top = temp->next;
    free(temp);

    return data;
}


void traverse(struct Node* top) {
    if (top == NULL) {
        printf("Stack is empty\n");
        return;
    }

    while (top != NULL) {
        printf("%d ", top->data);
        top = top->next;
    }
    printf("\n");
}


#include <stdio.h>

void inputMatrix(int matrix[10][10], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("Enter element at row %d, column %d: ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }
}

void printMatrix(int matrix[10][10], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}

void addMatrices(int mat1[10][10], int mat2[10][10], int result[10][10], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result[i][j] = mat1[i][j] + mat2[i][j];
        }
    }
}

void subtractMatrices(int mat1[10][10], int mat2[10][10], int result[10][10], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result[i][j] = mat1[i][j] - mat2[i][j];
        }
    }
}

void multiplyMatrices(int mat1[10][10], int mat2[10][10], int result[10][10], int rows1, int cols1, int cols2) {
    for (int i = 0; i < rows1; i++) {
        for (int j = 0; j < cols2; j++) {
            result[i][j] = 0;
            for (int k = 0; k < cols1; k++) {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }
}

int main() {
    int choice, rows1, cols1, rows2, cols2;
    int mat1[10][10], mat2[10][10], result[10][10];

    printf("Enter the number of rows and columns for the first matrix: ");
    scanf("%d %d", &rows1, &cols1);
    printf("Enter the number of rows and columns for the second matrix: ");
    scanf("%d %d", &rows2, &cols2);

    if (rows1 != rows2 || cols1 != cols2) {
        printf("Matrix addition and subtraction are not possible due to different dimensions.\n");
        return 1;
    }

    printf("Enter elements for the first matrix:\n");
    inputMatrix(mat1, rows1, cols1);
    printf("Enter elements for the second matrix:\n");
    inputMatrix(mat2, rows2, cols2);
do
{
    printf("Choose operation:\n");
    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
     printf("4. exit\n");
    printf("enter your choice\n");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            addMatrices(mat1, mat2, result, rows1, cols1);
            printf("Result of matrix addition:\n");
            printMatrix(result, rows1, cols1);
            break;

        case 2:
            subtractMatrices(mat1, mat2, result, rows1, cols1);
            printf("Result of matrix subtraction:\n");
            printMatrix(result, rows1, cols1);
            break;

        case 3:
            if (cols1 != rows2) {
                printf("Matrix multiplication is not possible \n");
            } else {
                multiplyMatrices(mat1, mat2, result, rows1, cols1, cols2);
                printf("Result of matrix multiplication:\n");
                printMatrix(result, rows1, cols2);
            }
            break;
            case 4:
              printf("exiting the program\n");
              break;
           
        default:
            printf("Invalid choice\n");
    }
    }while(choice!=4);
    

    return 0;
}


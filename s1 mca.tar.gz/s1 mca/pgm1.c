#include<stdio.h>
void swap(int x,int y)
{
int temp;
temp=x;
x=y;
y=temp;
printf("after swapping:a=%d \n b=%d\n\n",x,y);
}
void main()
{
int a,b;
printf("enter the two numbers:");
scanf("%d %d",&a,&b);
printf("before swapping a=%d \n  b=%d\n\n",a,b);
swap(a,b);
}

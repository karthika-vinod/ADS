#include <stdio.h>
int main() {
    int arr[100], n, choice, position, element;
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    printf("Enter the elements of the array:\n");
    for (int i = 0; i < n; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    do {
        printf("\nMenu:\n");
        printf("1. Insert an element at a particular position\n");
        printf("2. Delete an element from a particular position\n");
        printf("3. Traverse the array\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                // Insert an element at a particular position
                printf("Enter the position to insert: ");
                scanf("%d", &position);

                if (position < 1 || position > n + 1) {
                    printf("Invalid position!\n");
                } else {
                    printf("Enter the element to insert: ");
                    scanf("%d", &element);

                    for (int i = n; i >= position; i--) {
                        arr[i] = arr[i - 1];
                    }
                    arr[position - 1] = element;
                    n++;
                    printf("Element inserted successfully!\n");
                }
                break;
            case 2:
                // Delete an element from a particular position
                printf("Enter the position to delete: ");
                scanf("%d", &position);

                if (position < 1 || position > n) {
                    printf("Invalid position!\n");
                } else {
                    for (int i = position - 1; i < n - 1; i++) {
                        arr[i] = arr[i + 1];
                    }
                    n--;
                    printf("Element deleted successfully!\n");
                }
                break;
            case 3:
                // Traverse the array
                printf("Array elements: ");
                for (int i = 0; i < n; i++) {
                    printf("%d ", arr[i]);
                }
                printf("\n");
                break;
            case 4:
                // Exit the program
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);
    return 0;
}

